package br.com.estoque.joaopaulo.services;

import br.com.estoque.joaopaulo.model.Produto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProdutoService {
    @Autowired
    private ProdutoService produtoRepository;
    private Produto salvar(Produto produto){
        return produtoRepository.save(produto);
    }
}
